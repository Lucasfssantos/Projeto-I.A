from collections import deque

def bfs(graph, start, goal):
    queue = deque([[start]])  # Fila para manter os caminhos
    visited = set()  # Conjunto para marcar nós visitados
    
    while queue:
        path = queue.popleft()  # Remove o primeiro caminho da fila
        node = path[-1]  # Último nó do caminho
        
        if node in visited:  # Se já foi visitado continua
            continue
        
        visited.add(node)  # Adiciona o nó ao visitado
        
        if node == goal:  # Se atingiu a meta, retorna o caminho
            return path
        
        for neighbor in graph.get(node, []):  # Explora os vizinhos do nó atual
            new_path = list(path)  # Cria novo caminho
            new_path.append(neighbor)  # Acrescenta o vizinho ao novo caminho
            queue.append(new_path)  # Acrescenta o novo caminho à fila
    
    return None  # None se nenhum caminho for encontrado

# Grafo
graph = {
    'A': ['B', 'C'],
    'B': ['A', 'D', 'E'],
    'C': ['A', 'F'],
    'D': ['B'],
    'E': ['B', 'F'],
    'F': ['C', 'E']
}

start_node = 'A'  # Nó inicial
goal_node = 'F'  # Nó meta

bfs_path = bfs(graph, start_node, goal_node)  # Executa o bfs e armazena o caminho encontrado

print("Caminho encontrado (BFS): ", bfs_path)