def dfs(graph, start, goal):
    stack = [[start]]  # Pilha para manter os caminhos
    visited = set()  # Conjunto para marcar nós visitados
    
    while stack:
        path = stack.pop()  # Remove o último caminho da pilha
        node = path[-1]  # Último nó do caminho
        
        if node in visited:  # Se já foi visitado continua
            continue
        
        visited.add(node)  # Marca o nó ao visitado
        
        if node == goal:  # Se encontrou a meta, retorna o caminho
            return path
        
        for neighbor in reversed(graph.get(node, [])):  # Explora os vizinhos do nó atual em ordem reversa
            new_path = list(path)  # Cria novo caminho
            new_path.append(neighbor)  # Acrescenta o vizinho ao novo caminho
            stack.append(new_path)  # Acrescenta o novo caminho à pilha
    
    return None  # None se nenhum caminho for encontrado

# Grafo
graph = {
    'A': ['B', 'C'],
    'B': ['A', 'D', 'E'],
    'C': ['A', 'F'],
    'D': ['B'],
    'E': ['B', 'F'],
    'F': ['C', 'E']
}

start_node = 'A'  # Nó inicial
goal_node = 'F'  # Nó meta

dfs_path = dfs(graph, start_node, goal_node)  # Executa o dfs e armazena o caminho encontrado

print("Caminho encontrado (DFS): ", dfs_path)